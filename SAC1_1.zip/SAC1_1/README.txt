# 使用说明

## 项目结构

SAC1_1/
│
├── main.cpp
├── pics.qrc
├── SAC1_1.pro
├── SAC1_1.pro.user
├── widget.cpp
├── widget.h
├── widget.ui
├── 背景图/
└── build/
    └── SAC1_1 （可执行文件）


## 项目描述

该项目是一个基于Qt的图形用户界面（GUI）应用程序，用于系统级资源访问审计。主要功能包括：
- 显示日志条目
- 查找特定条件的日志
- 执行排序和合并操作
- 退出应用程序


## 配置和编译

1. 确保你的系统上已经安装了以下依赖：
   - Qt6 开发工具包
   - MySQL++ 库
   - MySQL 数据库

2. 克隆或下载该项目到本地目录。

3. 连接 MySQL 数据库。

4. 在Qt中打开已有项目，选择该项目目录下的SAC1_1.pro文件。

5. 在Qt中编译项目。

5. 编译完成后，可执行文件将位于 `build/` 文件夹中。

## 运行

直接在Qt中运行文件或在终端中导航到 `build` 文件夹并运行可执行文件：
$ ./SAC1_1


## 配置数据库

1. 确保MySQL数据库服务器正在运行。

2. 登录MySQL数据库并创建用户及赋予权限：

   ```sql
   CREATE USER 'admin'@'localhost' IDENTIFIED BY 'admin_password';
   GRANT ALL PRIVILEGES ON *.* TO 'admin'@'localhost' WITH GRANT OPTION;
   FLUSH PRIVILEGES;
   ```

3. 修改 `widget.cpp` 中的数据库连接信息以匹配你配置的数据库用户和密码。

## 主要功能和使用

### 1. 显示日志条目

应用程序启动后，日志条目将显示在 `QTableWidget` 中。

### 2. 查找日志条目

在 `QLineEdit` 中输入查找条件并点击 `查找` 按钮，满足条件的日志条目将显示在 `QTableWidget` 中。

### 3. 排序日志条目

输入排序条件和顺序（升序或降序），例如 `username ASC, time DESC`，然后点击 `排序` 按钮。

### 4. 合并日志条目

点击 `合并` 按钮执行合并操作。

### 5. 退出应用程序

点击 `退出` 按钮关闭应用程序。

