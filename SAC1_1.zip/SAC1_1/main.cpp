#include "widget.h"

#include <QApplication>
#include <cstdlib>

int main(int argc, char *argv[])
{
    //system("ls");
    system("lsmod");
    system("echo 'Pn13797356920' | sudo -S insmod /home/pengna/fileaudit/kernel-module/AuditModule.ko");
    //system("lsmod");
    // std::string comm = "mod";
    // std::string command = "ls" + comm;
    // std::system(command.c_str());
    QApplication a(argc, argv);
    Widget w;
    w.show();

    return a.exec();
}
