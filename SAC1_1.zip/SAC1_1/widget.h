#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QMessageBox>
#include <QApplication>
#include <QMainWindow>
#include <QTableWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QTableWidgetItem>

#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <linux/netlink.h>
#include <linux/socket.h>
#include <fcntl.h>
#include <asm/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <pwd.h>
#include <iostream>
#include <fstream>
#include <thread>
#include <mutex>
#include <unordered_map>
#include <sstream>
#include <atomic>
#include <mysql++/mysql++.h>
#include <vector>
#include <string>
#include <algorithm>

#define TM_FMT "%Y-%m-%d %H:%M:%S"
#define NETLINK_TEST 29
#define MAX_PAYLOAD 1024  /* maximum payload size*/

using namespace std;

extern bool finish_userInteraction;
extern int sock_fd;
extern struct msghdr msg;
extern struct nlmsghdr *nlh;
extern struct sockaddr_nl src_addr, dest_addr;
extern struct iovec iov;

extern std::string audit_path;
extern std::ofstream logfile;
extern std::mutex config_mutex;
extern std::unordered_map<std::string, bool> resource_flags;
extern std::atomic<bool> config_changed;
extern std::atomic<bool> stop_logging;

void readConfig(const std::string& config_file);
void writeConfig(const std::string& config_file);
void Log(const std::string& commandname, int uid, int pid, const std::string& file_path, int flags, int ret);
void sendpid(unsigned int pid);
void killdeal_func(int signum);
void logGeneration();
void userInteraction(const std::string& config_file);

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_pushButton_released();

    void on_pushButton_4_released();

    void on_pushButton_2_released();

    void on_pushButton_5_released();

    void on_pushButton_7_released();

    void on_pushButton_8_released();

    void on_pushButton_9_released();

    void on_pushButton_10_released();

    void on_pushButton_3_released();

    void on_pushButton_11_released();

    void on_pushButton_12_pressed();

    void on_pushButton_13_released();

    void on_pushButton_14_released();

    void on_pushButton_15_released();

    void on_pushButton_16_released();

    void on_pushButton_12_released();

    void on_pushButton_17_released();

    void on_pushButton_18_released();

    void on_pushButton_9_pressed();

    void on_pushButton_19_released();

    void on_pushButton_19_clicked();

private:
    Ui::Widget *ui;
};
#endif // WIDGET_H
