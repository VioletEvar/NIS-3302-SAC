#include "widget.h"
#include "ui_widget.h"

#include <unistd.h>
#include <QCoreApplication>
#include <QProcess>
#include <QDebug>

#include <mysql++/mysql++.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <ctime>

bool finish_userInteraction = false;
int sock_fd;
struct msghdr msg;
struct nlmsghdr *nlh = nullptr;
struct sockaddr_nl src_addr, dest_addr;
struct iovec iov;

string filename;
std::string audit_path;
std::ofstream logfile;
std::mutex config_mutex;
std::unordered_map<std::string, bool> resource_flags;
std::atomic<bool> config_changed(false);
std::atomic<bool> stop_logging(false);

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowTitle("Hello!");

    setStyleSheet("border-image:url(:/../../下载/背景图/pic_1.png);");
}

Widget::~Widget()
{
    delete ui;
}

// 读取配置文件内容，并更新配置标志
void readConfig(const std::string& config_file) {
    std::unordered_map<std::string, bool> temp_flags;
    std::ifstream file(config_file);
    if (!file.is_open()) {
        std::cerr << "Error opening config file." << std::endl;
        return;
    }
    std::string line;
    // 逐行读取配置文件内容
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string resource;
        bool flag;
        if (!(iss >> resource >> flag)) {
            std::cerr << "Error reading config line: " << line << std::endl;
            continue;
        }
        temp_flags[resource] = flag;
    }
    std::lock_guard<std::mutex> lock(config_mutex);
    resource_flags = std::move(temp_flags);
    config_changed = true;
}

// 将配置标志写入配置文件
void writeConfig(const std::string& config_file) {
    std::lock_guard<std::mutex> lock(config_mutex);  // 线程安全锁
    std::ofstream file(config_file);
    if (!file.is_open()) {
        std::cerr << "Error opening config file for writing." << std::endl;
        return;
    }
    for (const auto& [resource, flag] : resource_flags) {
        file << resource << " " << flag << std::endl;
    }
}

// 日志记录函数
void Log(const std::string& commandname, int uid, int pid, const std::string& file_path, int flags, int ret) {
    bool should_log = false;
    {
        std::lock_guard<std::mutex> lock(config_mutex);
        if (resource_flags.find(commandname) != resource_flags.end() && resource_flags[commandname]) {
            should_log = true;
        }
    }

    if (!should_log) {
        return;
    }

    char logtime[64];
    char username[32];
    struct passwd *pwinfo;
    std::string operationresult;
    std::string operationtype;

    if (ret >= 0) operationresult = "success";
    else operationresult = "failed";

    // 确定操作类型
    if (commandname == "rm") {
        operationtype = "Delete";
    }
    else if(commandname == "insmod"){
        operationtype = "ModuleInstall";
    }
    else if(commandname == "rmmod"){
        operationtype = "ModuleRemove";
    }
    else if(commandname == "reboot"){
        operationtype = "Reboot";
    }
    else if(commandname == "shutdown"){
        operationtype = "Shutdown";
    }
    else if(commandname == "mount"){
        operationtype = "umount";
    }
    else if(commandname == "socket"){
        operationtype = "Socket";
    }
    else if(commandname == "connect"){
        operationtype = "Connect";
    }
    else if(commandname == "accept"){
        operationtype = "Accept";
    }
    else if(commandname == "sendto"){
        operationtype = "Sendto";
    }
    else if(commandname == "recvfrom"){
        operationtype = "Recvfrom";
    }
    else if(commandname == "close"){
        operationtype = "Close";
    }
    else if(flags == 524288){
        operationtype = "Execute";
    }
    else {
        if (flags & O_RDONLY) operationtype = "Read";
        else if (flags & O_WRONLY) operationtype = "Write";
        else if (flags & O_RDWR) operationtype = "Read/Write";
        else operationtype = "Other";
    }

    time_t t = time(0);
    if (!logfile.is_open()) return;
    pwinfo = getpwuid(uid);
    strcpy(username, pwinfo->pw_name);

    strftime(logtime, sizeof(logtime), TM_FMT, localtime(&t));

    // 写入日志文件
    logfile << username << "(" << uid << ") " << commandname << "(" << pid << ") " << logtime
            << " \"" << file_path << "\" " << operationtype << " " << operationresult << std::endl;
    logfile.flush();
}

// 发送进程ID到内核模块
void sendpid(unsigned int pid) {
    // Send message to initialize
    memset(&msg, 0, sizeof(msg));
    memset(&src_addr, 0, sizeof(src_addr));
    src_addr.nl_family = AF_NETLINK;
    src_addr.nl_pid = pid;  // self pid
    src_addr.nl_groups = 0;  // not in mcast groups
    bind(sock_fd, (struct sockaddr*)&src_addr, sizeof(src_addr));

    memset(&dest_addr, 0, sizeof(dest_addr));
    dest_addr.nl_family = AF_NETLINK;
    dest_addr.nl_pid = 0;   // For Linux Kernel
    dest_addr.nl_groups = 0; // unicast

    // Fill the netlink message header
    nlh->nlmsg_len = NLMSG_SPACE(MAX_PAYLOAD);
    nlh->nlmsg_pid = pid;  // self pid
    nlh->nlmsg_flags = 0;

    strcpy((char *)NLMSG_DATA(nlh), "Hello");
    iov.iov_base = (void *)nlh;
    iov.iov_len = nlh->nlmsg_len;
    msg.msg_name = (void *)&dest_addr;
    msg.msg_namelen = sizeof(dest_addr);
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;

    std::cout << "Sending message pid. ..." << std::endl;
    sendmsg(sock_fd, &msg, 0);
}

// 信号处理函数，用于处理进程被终止的情况
void killdeal_func(int signum) {
    std::cout << "The process is killed!" << std::endl;
    close(sock_fd);
    if (logfile.is_open())
        logfile.close();
    if (nlh != nullptr)
        free(nlh);  // 释放Netlink消息
    exit(0);
}

void logGeneration() {
    // Set the socket to non-blocking mode
    int flags = fcntl(sock_fd, F_GETFL, 0);
    fcntl(sock_fd, F_SETFL, flags | O_NONBLOCK);

    while (!stop_logging) {
        if (config_changed) {
            std::lock_guard<std::mutex> lock(config_mutex);
            config_changed = false;
            // Print "logging enabled for resource" message when config is updated
            for (const auto& [resource, flag] : resource_flags) {
                if (flag) {
                    std::cout << "Logging enabled for resource: " << resource << std::endl;
                }
            }
        }

        // Read message from kernel
        unsigned int uid, pid, flags, ret;
        char *file_path;
        char *commandname;

        int ret_val = recvmsg(sock_fd, &msg, 0);
        if (ret_val < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));  // Short sleep to avoid busy-waiting
                continue;
            } else {
                perror("recvmsg");
                break;
            }
        }

        // Analyze log info
        uid = *(reinterpret_cast<unsigned int *>(NLMSG_DATA(nlh)));
        pid = *(1 + reinterpret_cast<int *>(NLMSG_DATA(nlh)));
        flags = *(2 + reinterpret_cast<int *>(NLMSG_DATA(nlh)));
        ret = *(3 + reinterpret_cast<int *>(NLMSG_DATA(nlh)));
        commandname = reinterpret_cast<char *>(4 + reinterpret_cast<int *>(NLMSG_DATA(nlh)));
        file_path = reinterpret_cast<char *>(4 + 16 / 4 + reinterpret_cast<int *>(NLMSG_DATA(nlh)));

        // Check resource flags
        bool should_log = false;
        {
            std::lock_guard<std::mutex> lock(config_mutex);
            auto it = resource_flags.find(commandname);
            if (it != resource_flags.end() && it->second) {
                should_log = true;
            }
        }

        if (!should_log) {
            continue;
        }

        // Print log info
        std::cout << "uid: " << uid << std::endl;
        std::cout << "pid: " << pid << std::endl;
        std::cout << "flags: " << flags << std::endl;
        std::cout << "ret: " << ret << std::endl;
        std::cout << "commandname: " << commandname << std::endl;
        std::cout << "file_path: " << file_path << std::endl;

        // Generate log
        Log(commandname, uid, pid, file_path, flags, ret);
    }
}

void userInteraction(const std::string& config_file) {
    // 用户交互循环
    while(true){
        if (finish_userInteraction == true)
            break;
    }

    stop_logging = true;
    writeConfig(config_file);

}


//打印帮助界面
void Widget::on_pushButton_released()
{
    ui->stackedWidget->setCurrentWidget(ui->PageHelp);
}

//退出程序
void Widget::on_pushButton_4_released()
{
    close();
}

//开始监控
void Widget::on_pushButton_2_released()
{
    ui->stackedWidget->setCurrentWidget(ui->PageMoniPath);
}

//监控目录
void Widget::on_pushButton_5_released()
{
    //检查audit_path输入是否为空
    bool check = ui->audit_pathEdit->text().isEmpty();

    if(!check){
        QString qaudit_path = ui->audit_pathEdit->text();
        audit_path = qaudit_path.toStdString();
        //QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("成功进入监控目录"), QMessageBox::Yes);
        ui->stackedWidget->setCurrentWidget(ui->PageFromLYT);

        finish_userInteraction = true;
    }
    else{
        QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("监控目录为空！"), QMessageBox::Yes);
    }
}

//执行command
void Widget::on_pushButton_7_released()
{
    QString qcommand = ui->commandBox->currentText();
    string logpath = "/home/pengna/fileaudit/configure/log.txt"; //日志目录
    string config_file = "/home/pengna/config.txt";

    string commandname = qcommand.toStdString();


    signal(SIGTERM, killdeal_func);
    sock_fd = socket(PF_NETLINK, SOCK_RAW, NETLINK_TEST);
    //确保 socket 文件描述符被正确创建
    if (sock_fd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }
    nlh = (struct nlmsghdr *)malloc(NLMSG_SPACE(MAX_PAYLOAD));
    memset(nlh, 0, NLMSG_SPACE(MAX_PAYLOAD));

    sendpid(getpid());

    logfile.open(logpath, std::ios::out | std::ios::app);
    if (!logfile.is_open()) {
        std::cerr << "Warning: cannot create log file" << std::endl;
        exit(1);
    }

    readConfig(config_file);

    std::thread log_thread(logGeneration);
    std::thread user_thread(userInteraction, config_file);

    string audit_path1 = "cd " + audit_path + "\n";
    QString qaudit_path = QString::fromStdString(audit_path1);
    QString qcommand1 = "cd &&"
                        + qaudit_path
                        + qcommand;
    string command1 = qcommand1.toStdString();

    int result = std::system(command1.c_str());

    // 检查命令执行结果
    if (result == 0) {
        std::cout << "Commands executed successfully" << std::endl;
    } else {
        std::cout << "Error executing commands" << std::endl;
    }

    QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("操作成功执行"), QMessageBox::Yes);

    user_thread.join();
    log_thread.join();

    ::close(sock_fd);
    free(nlh);
    if (logfile.is_open())
        logfile.close();

}

//从PageFromLYT页面停止监控
void Widget::on_pushButton_8_released()
{
    finish_userInteraction = true;
    ui->stackedWidget->setCurrentWidget(ui->PageStart);
}

//更新监控目录
void Widget::on_pushButton_9_released()
{
    finish_userInteraction = true;
    ui->stackedWidget->setCurrentWidget(ui->PageMoniPath);
}

//从PageFromLYT页面返回主界面
void Widget::on_pushButton_10_released()
{
    finish_userInteraction = true;
    ui->stackedWidget->setCurrentWidget(ui->PageStart);
}


//日志信息查看模块
//日志条目结构体
struct LogEntry {
    std::string username;
    int uid;
    std::string operation;
    int operation_id;
    std::string time;
    std::string file_path;
    std::string details;
    std::string status;

};

// 从文件读取日志条目
std::vector<LogEntry> readLogFile(const std::string& filename) {
    std::ifstream file(filename);
    std::vector<LogEntry> logEntries;
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        LogEntry entry;

        std::getline(iss, entry.username, '(');
        iss >> entry.uid;
        iss.ignore(2, ' ');
        std::getline(iss, entry.operation, '(');
        iss >> entry.operation_id;
        iss.ignore(2, ' ');

        // 读取完整的时间部分，包括日期和时间
        std::getline(iss, entry.time, ' ');
        std::string timePart;
        std::getline(iss, timePart, ' ');
        entry.time += " " + timePart;

        std::getline(iss, entry.file_path, '"');
        std::getline(iss, entry.file_path, '"');

        int size = entry.file_path.size()-1;
        if(entry.file_path[size] == '.') entry.file_path.pop_back();

        iss.ignore(1);
        std::getline(iss, entry.details, ' ');
        logEntries.push_back(entry);
    }
    std::cout << "Read " << logEntries.size() << " log entries from file." << std::endl; // 调试输出
    return logEntries;
}

// 连接数据库
mysqlpp::Connection connectDatabase() {
    mysqlpp::Connection conn(false);
    try {
        const char* db = "log_db";
        const char* server = "localhost";
        const char* user = "admin";
        const char* password = "admin_password";

        if (!conn.connect(db, server, user, password)) {
            std::cerr << "Connection failed: " << conn.error() << std::endl;
            throw std::runtime_error("DB connection failed: " + std::string(conn.error()));
        }
    } catch (const std::exception& ex) {
        std::cerr << "Exception: " << ex.what() << std::endl;
    }
    std::cout << "Connected to database successfully." << std::endl;
    return conn;
}

// 清空日志条目表
void clearLogEntries(mysqlpp::Connection& conn) {
    mysqlpp::Query query = conn.query("TRUNCATE TABLE log_entries");
    query.execute();
    std::cout << "Cleared log_entries table." << std::endl; // 调试输出
}

// 将日志条目逐个插入数据库
void insertLogEntries(mysqlpp::Connection& conn, const std::vector<LogEntry>& logEntries) {
    for (const auto& entry : logEntries) {
        // 使用参数化查询以防止SQL注入
        mysqlpp::Query query = conn.query();
        query << "INSERT INTO log_entries (username, uid, operation, operation_id, time, file_path, details, status) " << "VALUES (%0q, %1, %2q, %3, %4q, %5q, %6q, %7q)";
        query.parse();
        try {query.execute(entry.username, entry.uid, entry.operation, entry.operation_id, entry.time, 	entry.file_path, entry.details, entry.status);}
        catch (const mysqlpp::BadQuery& e) {std::cerr << "Query error: " << e.what() << std::endl;}
        catch (const mysqlpp::Exception& e) {std::cerr << "Error: " << e.what() << std::endl;}
    }
    std::cout << "Inserted " << logEntries.size() << " log entries into database." << std::endl; // 调试输出
}

// 根据条件查询日志条目
std::vector<LogEntry> queryLogEntries(mysqlpp::Connection& conn, const std::string& condition) {
    mysqlpp::Query query = conn.query("SELECT username, uid, operation, operation_id, time, file_path, details, status FROM log_entries WHERE "+ condition);
    mysqlpp::StoreQueryResult res = query.store();
    std::vector<LogEntry> logEntries;
    for (size_t i = 0; i < res.num_rows(); ++i) {
        LogEntry entry;
        entry.username = res[i]["username"].c_str();
        entry.uid = res[i]["uid"];
        entry.operation = res[i]["operation"].c_str();
        entry.operation_id = res[i]["operation_id"];
        entry.time = res[i]["time"].c_str();
        entry.file_path = res[i]["file_path"].c_str();
        entry.details = res[i]["details"].c_str();
        entry.status = res[i]["status"].c_str();
        logEntries.push_back(entry);
    }
    std::cout << "Queried " << logEntries.size() << " log entries with condition: " << condition << std::endl; // 调试输出
    return logEntries;
}

// 根据字段排序日志条目
std::vector<LogEntry> sortLogEntries(mysqlpp::Connection& conn, const std::string& field) {
    mysqlpp::Query query = conn.query("SELECT username, uid, operation, operation_id, time, file_path, details, status FROM log_entries ORDER BY " + field);
    mysqlpp::StoreQueryResult res = query.store();
    std::vector<LogEntry> logEntries;
    for (size_t i = 0; i < res.num_rows(); ++i) {
        LogEntry entry;
        entry.username = res[i]["username"].c_str();
        entry.uid = res[i]["uid"];
        entry.operation = res[i]["operation"].c_str();
        entry.operation_id = res[i]["operation_id"];
        entry.time = res[i]["time"].c_str();
        entry.file_path = res[i]["file_path"].c_str();
        entry.details = res[i]["details"].c_str();
        entry.status = res[i]["status"].c_str();
        logEntries.push_back(entry);
    }
    std::cout << "Sorted " << logEntries.size() << " log entries by " << field << std::endl; // 调试输出
    return logEntries;
}

// 合并日志条目
std::vector<LogEntry> mergeLogEntries(mysqlpp::Connection& conn) {
    mysqlpp::Query query = conn.query("SELECT username, uid, operation, operation_id, time, file_path, details, status FROM log_entries ORDER BY time");
    mysqlpp::StoreQueryResult res = query.store();
    std::vector<LogEntry> logEntries;
    LogEntry lastEntry;
    for (size_t i = 0; i < res.num_rows(); ++i) {
        LogEntry entry;
        entry.username = res[i]["username"].c_str();
        entry.uid = res[i]["uid"];
        entry.operation = res[i]["operation"].c_str();
        entry.operation_id = res[i]["operation_id"];
        entry.time = res[i]["time"].c_str();
        entry.file_path = res[i]["file_path"].c_str();
        entry.details = res[i]["details"].c_str();
        entry.status = res[i]["status"].c_str();

        if (i == 0 || entry.username != lastEntry.username || entry.uid != lastEntry.uid || entry.operation != lastEntry.operation || entry.file_path != lastEntry.file_path || entry.details!= lastEntry.details || entry.status != lastEntry.status) {
            logEntries.push_back(entry);
        }
        else {
            logEntries.back() = entry; // 更新为最新的操作
        }
        lastEntry = entry;
    }
    std::cout << "Merged log entries, resulting in " << logEntries.size() << " unique entries." << std::endl; // 调试输出
    return logEntries;
}

// 输出日志条目
void printLogEntries(const std::vector<LogEntry>& logEntries) {
    const int colWidth = 20;
    std::cout << std::left << std::setw(colWidth) << "| username"
              << std::left << std::setw(colWidth) << "| uid"
              << std::left << std::setw(colWidth) << "| operation"
              << std::left << std::setw(colWidth) << "| operation_id"
              << std::left << std::setw(colWidth) << "| time"
              << std::left << std::setw(colWidth) << "| file_path"
              << std::left << std::setw(colWidth) << "| details"
              << std::left << std::setw(colWidth) << "| status"
              << std::endl;
    for (const auto& entry : logEntries) {
        std::cout << "| " << std::left << std::setw(colWidth) << entry.username
                  << "| " << std::left << std::setw(colWidth) << entry.uid
                  << "| " << std::left << std::setw(colWidth) << entry.operation
                  << "| " << std::left << std::setw(colWidth) << entry.operation_id
                  << "| " << std::left << std::setw(colWidth) << entry.time
                  << "| " << std::left << std::setw(colWidth) << entry.file_path
                  << "| " << std::left << std::setw(colWidth) << entry.details
                  << "| " << std::left << std::setw(colWidth) << entry.status
                  << std::endl;
    }
}

//void queryOption(mysqlpp::Connection& conn)

//void sortOption(mysqlpp::Connection& conn)

//void mergeMode(mysqlpp::Connection& conn)

//帮助页面
void userHelp(){
    std::cout << "Welcome to the Log Management System. This system supports the following operations on log entries:" << std::endl ;
    std::cout << "query: Retrieve log entries based on specific conditions." << std::endl;
    std::cout << "sort: Sort and output log entries based on specific conditions." << std::endl;
    std::cout << "merge: Merge and output log entries with duplicate operations." << std::endl;
    std::cout << "quit: Exit the system." << std::endl;
    return ;
}

// 提取最后一项内容的函数
std::string extractLastItem(const std::string& line) {
    size_t lastCommaPos = line.rfind(' ');
    if (lastCommaPos != std::string::npos) {
        std::string lastItem = line.substr(lastCommaPos + 1);
        // 去除前后的空格
        lastItem.erase(0, lastItem.find_first_not_of(' '));
        lastItem.erase(lastItem.find_last_not_of(' ') + 1);
        return lastItem;
    }
    return "";
}





//查看日志信息
void Widget::on_pushButton_3_released()
{
    ui->stackedWidget->setCurrentWidget(ui->PageLogPath);
}

//日志路径
void Widget::on_pushButton_11_released()
{
    QString qlog_path = ui->log_pathEdit->text();
    filename = qlog_path.toStdString();

    // 读取日志文件
    std::vector<LogEntry> logEntries = readLogFile(filename);//命令行输入

    std::ifstream file(filename);
    if(!file.is_open()){
        std:: cerr << "Error opening file." << std:: endl;
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("Error opening file!"), QMessageBox::Yes);
    }

    std::string line;
    size_t i = 0;
    while(std::getline(file, line)) {
        logEntries[i].status = extractLastItem(line);
        std::cout << "Last item :" << logEntries[i].status << " " << logEntries[i].status.size() << std::endl; //调试信息
        i++;
    }

    // 连接到数据库
    mysqlpp::Connection conn = connectDatabase();
    //QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("正常！"), QMessageBox::Yes);

    // 帮助界面
    userHelp();

    ui->stackedWidget->setCurrentWidget(ui->PageFromKB);
    QString qusername = QString::fromStdString("pengna");
    ui->usernameEdit->setText(qusername);
    QString quid = QString::fromStdString("1000");
    ui->uidEdit->setText(quid);
    // QString qoperation = QString::fromStdString("ls");
    // ui->operationEdit->setText(qoperation);
    // QString qoperation_id = QString::fromStdString("11114");
    // ui->operation_idEdit->setText(qoperation_id);
    // QString qtime = QString::fromStdString("2024-07-12 10:56:41");
    // ui->timeEdit->setText(qtime);
    // QString qfile_path = QString::fromStdString("/home/TestAudit/");
    // ui->file_pathEdit->setText(qfile_path);
    // QString qdetails = QString::fromStdString("Other");
    // ui->detailsEdit->setText(qdetails);
    // QString qstatus = QString::fromStdString("success");
    // ui->statusEdit->setText(qstatus);

}

//query功能
void Widget::on_pushButton_12_pressed()
{
    // 读取日志文件
    std::vector<LogEntry> logEntries = readLogFile(filename);//命令行输入

    std::ifstream file(filename);
    if(!file.is_open()){
        std:: cerr << "Error opening file." << std:: endl;
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("Error opening file!"), QMessageBox::Yes);
    }

    std::string line;
    size_t i = 0;
    while(std::getline(file, line)) {
        logEntries[i].status = extractLastItem(line);
        std::cout << "Last item :" << logEntries[i].status << " " << logEntries[i].status.size() << std::endl; //调试信息
        i++;
    }

    //连接到数据库
    mysqlpp::Connection conn = connectDatabase();
    //QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("正常！"), QMessageBox::Yes);

    // 帮助界面
    userHelp();

    //清空数据库表
    clearLogEntries(conn);
    //将日志条目插入数据库
    insertLogEntries(conn, logEntries);

    std::string queryCondition;
    queryCondition.clear();
    bool queryCondition_flag = false;

    queryCondition = (ui->usernameEdit->text()).toStdString();
    queryCondition_flag = true;
    queryCondition = "username = \'" + queryCondition + "\'" ;

    std::string otherCondition;
    otherCondition = (ui->uidEdit->text()).toStdString();
    if (otherCondition != "")
        queryCondition = queryCondition + " AND uid = \'" + otherCondition + "\'";
    otherCondition = (ui->operationEdit->text()).toStdString();
    if (otherCondition != "")
        queryCondition = queryCondition + " AND operation = \'" + otherCondition + "\'";
    otherCondition = (ui->operation_idEdit->text()).toStdString();
    if (otherCondition != "")
        queryCondition = queryCondition + " AND operation_id = \'" + otherCondition + "\'";
    otherCondition = (ui->timeEdit->text()).toStdString();
    if (otherCondition != "")
        queryCondition = queryCondition + " AND time = \'" + otherCondition + "\'";
    otherCondition = (ui->file_pathEdit->text()).toStdString();
    if (otherCondition != "")
        queryCondition = queryCondition + " AND file_path = \'" + otherCondition + "\'";
    otherCondition = (ui->detailsEdit->text()).toStdString();
    if (otherCondition != "")
        queryCondition = queryCondition + " AND details = \'" + otherCondition + "\'";
    otherCondition = (ui->statusEdit->text()).toStdString();
    if (otherCondition != "")
        queryCondition = queryCondition + " AND status = \'" + otherCondition + "\'";

    std::vector<LogEntry> queriedEntries = queryLogEntries(conn, queryCondition);
    std::cout << "Queried Entries by " << queryCondition << std::endl;
    printLogEntries(queriedEntries);

    for (const auto& entry : queriedEntries) {
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        int rowIdx = ui->tableWidget->rowCount() - 1;
        QTableWidgetItem *item0 = new QTableWidgetItem(QString::fromStdString(entry.username));
        ui->tableWidget->setItem(rowIdx, 0, item0);
        QTableWidgetItem *item1 = new QTableWidgetItem(QString::number(entry.uid));
        ui->tableWidget->setItem(rowIdx, 1, item1);
        QTableWidgetItem *item2 = new QTableWidgetItem(QString::fromStdString(entry.operation));
        ui->tableWidget->setItem(rowIdx, 2, item2);
        QTableWidgetItem *item3 = new QTableWidgetItem(QString::number(entry.operation_id));
        ui->tableWidget->setItem(rowIdx, 3, item3);
        QTableWidgetItem *item4 = new QTableWidgetItem(QString::fromStdString(entry.time));
        ui->tableWidget->setItem(rowIdx, 4, item4);
        QTableWidgetItem *item5 = new QTableWidgetItem(QString::fromStdString(entry.file_path));
        ui->tableWidget->setItem(rowIdx, 5, item5);
        QTableWidgetItem *item6 = new QTableWidgetItem(QString::fromStdString(entry.details));
        ui->tableWidget->setItem(rowIdx, 6, item6);
        QTableWidgetItem *item7 = new QTableWidgetItem(QString::fromStdString(entry.status));
        ui->tableWidget->setItem(rowIdx, 7, item7);

    }
}

//sort功能
void Widget::on_pushButton_13_released()
{
    // 读取日志文件
    std::vector<LogEntry> logEntries = readLogFile(filename);//命令行输入

    std::ifstream file(filename);
    if(!file.is_open()){
        std:: cerr << "Error opening file." << std:: endl;
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("Error opening file!"), QMessageBox::Yes);
    }

    std::string line;
    size_t i = 0;
    while(std::getline(file, line)) {
        logEntries[i].status = extractLastItem(line);
        std::cout << "Last item :" << logEntries[i].status << " " << logEntries[i].status.size() << std::endl; //调试信息
        i++;
    }

    //连接到数据库
    mysqlpp::Connection conn = connectDatabase();
    //QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("正常！"), QMessageBox::Yes);

    // 帮助界面
    userHelp();

    //清空数据库表
    clearLogEntries(conn);
    //将日志条目插入数据库
    insertLogEntries(conn, logEntries);

    std::string sortCondition;
    sortCondition.clear();

    sortCondition = (ui->sortEdit->text()).toStdString();
    std::vector<LogEntry> sortedEntries = sortLogEntries(conn, sortCondition);
    std::cout << "Sorted Entries by " << sortCondition << std::endl;
    printLogEntries(sortedEntries);

    for (const auto& entry : sortedEntries) {
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        int rowIdx = ui->tableWidget->rowCount() - 1;
        QTableWidgetItem *item0 = new QTableWidgetItem(QString::fromStdString(entry.username));
        ui->tableWidget->setItem(rowIdx, 0, item0);
        QTableWidgetItem *item1 = new QTableWidgetItem(QString::number(entry.uid));
        ui->tableWidget->setItem(rowIdx, 1, item1);
        QTableWidgetItem *item2 = new QTableWidgetItem(QString::fromStdString(entry.operation));
        ui->tableWidget->setItem(rowIdx, 2, item2);
        QTableWidgetItem *item3 = new QTableWidgetItem(QString::number(entry.operation_id));
        ui->tableWidget->setItem(rowIdx, 3, item3);
        QTableWidgetItem *item4 = new QTableWidgetItem(QString::fromStdString(entry.time));
        ui->tableWidget->setItem(rowIdx, 4, item4);
        QTableWidgetItem *item5 = new QTableWidgetItem(QString::fromStdString(entry.file_path));
        ui->tableWidget->setItem(rowIdx, 5, item5);
        QTableWidgetItem *item6 = new QTableWidgetItem(QString::fromStdString(entry.details));
        ui->tableWidget->setItem(rowIdx, 6, item6);
        QTableWidgetItem *item7 = new QTableWidgetItem(QString::fromStdString(entry.status));
        ui->tableWidget->setItem(rowIdx, 7, item7);

    }
}

//merge功能
void Widget::on_pushButton_14_released()
{
    // 读取日志文件
    std::vector<LogEntry> logEntries = readLogFile(filename);//命令行输入

    std::ifstream file(filename);
    if(!file.is_open()){
        std:: cerr << "Error opening file." << std:: endl;
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("Error opening file!"), QMessageBox::Yes);
    }

    std::string line;
    size_t i = 0;
    while(std::getline(file, line)) {
        logEntries[i].status = extractLastItem(line);
        std::cout << "Last item :" << logEntries[i].status << " " << logEntries[i].status.size() << std::endl; //调试信息
        i++;
    }

    //连接到数据库
    mysqlpp::Connection conn = connectDatabase();
    //QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("正常！"), QMessageBox::Yes);

    // 帮助界面
    userHelp();

    //清空数据库表
    clearLogEntries(conn);
    //将日志条目插入数据库
    insertLogEntries(conn, logEntries);

    std::vector<LogEntry> mergedEntries = mergeLogEntries(conn);
    std::cout << "Merged Entries:" << std::endl;
    printLogEntries(mergedEntries);

    for (const auto& entry : mergedEntries) {
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        int rowIdx = ui->tableWidget->rowCount() - 1;
        QTableWidgetItem *item0 = new QTableWidgetItem(QString::fromStdString(entry.username));
        ui->tableWidget->setItem(rowIdx, 0, item0);
        QTableWidgetItem *item1 = new QTableWidgetItem(QString::number(entry.uid));
        ui->tableWidget->setItem(rowIdx, 1, item1);
        QTableWidgetItem *item2 = new QTableWidgetItem(QString::fromStdString(entry.operation));
        ui->tableWidget->setItem(rowIdx, 2, item2);
        QTableWidgetItem *item3 = new QTableWidgetItem(QString::number(entry.operation_id));
        ui->tableWidget->setItem(rowIdx, 3, item3);
        QTableWidgetItem *item4 = new QTableWidgetItem(QString::fromStdString(entry.time));
        ui->tableWidget->setItem(rowIdx, 4, item4);
        QTableWidgetItem *item5 = new QTableWidgetItem(QString::fromStdString(entry.file_path));
        ui->tableWidget->setItem(rowIdx, 5, item5);
        QTableWidgetItem *item6 = new QTableWidgetItem(QString::fromStdString(entry.details));
        ui->tableWidget->setItem(rowIdx, 6, item6);
        QTableWidgetItem *item7 = new QTableWidgetItem(QString::fromStdString(entry.status));
        ui->tableWidget->setItem(rowIdx, 7, item7);

    }
}

//从PageFromKB页面返回主界面
void Widget::on_pushButton_15_released()
{
    ui->stackedWidget->setCurrentWidget(ui->PageStart);
}


void Widget::on_pushButton_16_released()
{
    ui->stackedWidget->setCurrentWidget(ui->PageStart);
}

void Widget::on_pushButton_12_released()
{
    //
}

//admin用户登陆
void Widget::on_pushButton_17_released()
{
    QString qpasswd = ui->passwdEdit->text();
    string passwd = qpasswd.toStdString();
    if (passwd == "admin_password"){
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("登陆成功"), QMessageBox::Yes);
        ui->stackedWidget->setCurrentWidget(ui->PageStart);
    }
    else{
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("密码错误"), QMessageBox::Yes);
        ui->passwdEdit->clear();
    }
}


void Widget::on_pushButton_18_released()
{
    close();
}


void Widget::on_pushButton_19_released()
{
    ui->stackedWidget->setCurrentWidget(ui->PageLogin);
}


void Widget::on_pushButton_19_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->PageLogin);
}

